OkHttp URLConnection
====================

This module integrates OkHttp with `Authenticator` and `CookieHandler` from `java.net`.

### Download

```kotlin
testImplementation("com.squareup.okhttp3:okhttp-urlconnection:4.9.1")
```
