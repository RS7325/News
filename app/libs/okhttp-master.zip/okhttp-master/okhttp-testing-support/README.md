OkHttp Testing Support
======================

This module offers utilities and support for testing OkHttp itself. It's not intended for use by
other projects or consumers of the OkHttp library.
